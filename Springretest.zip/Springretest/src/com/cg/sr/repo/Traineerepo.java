package com.cg.sr.repo;


import java.util.List;


import com.cg.sr.bean.TraineeBean;

public interface Traineerepo {
	
	public TraineeBean addtrainee(TraineeBean traineebean);
	public TraineeBean findTrainee(int traineeid);
	List<TraineeBean> gettraineeList();
	public void deleteTrainee(int traineeid);
    public void updateTrainee(TraineeBean traineebean);
	

}
