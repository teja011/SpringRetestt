package com.cg.sr.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.sr.bean.TraineeBean;
@Repository
public class Traineerepoimpl implements Traineerepo {
	
	@PersistenceContext
	EntityManager manager;

	@Override
	public TraineeBean addtrainee(TraineeBean traineebean) {
		
		manager.persist(traineebean);
		manager.flush();
		return traineebean;
	}

	@Override
	public TraineeBean findTrainee(int traineeid) {
		
		return manager.find(TraineeBean.class, traineeid);
	}

	@Override
	public List<TraineeBean> gettraineeList() {
		String str= "select traineebean from TraineeBean traineebean";
		TypedQuery<TraineeBean> query = manager.createQuery(str, TraineeBean.class);
		List<TraineeBean> Tlist = query.getResultList();
		return Tlist;
	}

	@Override
	public void deleteTrainee(int traineeid) {
		TraineeBean traineebean = manager.find(TraineeBean.class, traineeid );
		manager.remove(traineebean);
	}

	@Override
	public void updateTrainee(TraineeBean traineebean) {
		
		manager.merge(traineebean);
	}

	

}
