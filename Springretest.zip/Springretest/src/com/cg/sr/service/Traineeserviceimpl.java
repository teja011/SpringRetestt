package com.cg.sr.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sr.bean.TraineeBean;
import com.cg.sr.repo.Traineerepo;

@Service
@Transactional
public class Traineeserviceimpl implements Traineeservice {
    
	@Autowired
	Traineerepo trepo;
	
	
	
	public Traineerepo getTrepo() {
		return trepo;
	}



	public void setTrepo(Traineerepo trepo) {
		this.trepo = trepo;
	}



	@Override
	public TraineeBean addTrainee(TraineeBean traineebean) {
		
		return trepo.addtrainee(traineebean);
	}



	@Override
	public TraineeBean findTrainee(int traineeid) {
		
		return trepo.findTrainee(traineeid);
		
	}



	@Override
	public List<TraineeBean> gettraineeList() {
		
		return trepo.gettraineeList();
	}


     @Override
	public void deleteTrainee(int traineeid) {
	
		trepo.deleteTrainee(traineeid);
		
	}



	@Override
	public void updateTrainee(TraineeBean traineebean) {
	
	trepo.updateTrainee(traineebean);	
	}

}
